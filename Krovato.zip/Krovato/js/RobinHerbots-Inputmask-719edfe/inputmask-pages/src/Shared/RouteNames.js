export default {
  Home: "/",
  Documentation: "/documentation",
  Documentation_Extensions: "/documentation/extensions",
  Documentation_Datetime: "/documentation/datetime",
  Documentation_Numeric: "/documentation/numeric",
  Documentation_Colormask: "/documentation/colormask",
  Demo: "/demo",
  Factory: "/factory",
  Changelog: "/changelog"
};
