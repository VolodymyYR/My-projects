"use strict"

const isTouchScreen = window.matchMedia("(any-hover:none)").matches

window.addEventListener('load', windowLoaded)

// ================================================================================================
// ==============================================================================================================================
// ===============================================================================================================================================
// ==============================================================================================================================
// ================================================================================================


function windowLoaded(){
    const maxWidth = +document.querySelector('.footer-menu').dataset.spoilersInit || 600;
    const menuFooter = document.querySelector('.footer-menu')

// ================================================================================================
// ================================================================================================
// ================================================================================================

    let documentActions = (e) =>{
        const targetElement = e.target;
        const typeEvent = e.type;
        const targetTag = targetElement.tagName;
        // ----------------------------------------------------------------------------------------------------------------------------------
        if(targetElement.closest('[data-spoller-title]')){
            const footerSpollerTitle = targetElement.closest('[data-spoller-title]')
            const maxWidth = +footerSpollerTitle.closest('[data-spoller]').dataset.spoller
            if (maxWidth ? window.innerWidth <= maxWidth : true) {
                if (!footerSpollerTitle.querySelectorAll('._slide').length) {
                    const spollerParents = targetElement.closest('[data-spoller-parents]');
                    const footerActiveSpoller = spollerParents.querySelector('[data-spoller][open]')
                    const spollerParentsStatus = spollerParents.dataset.spollerParents || true;
                    if (spollerParentsStatus == true){
                        if (footerActiveSpoller && footerActiveSpoller !== targetElement.closest('[data-spoller]')) {
                        spollersAnim(footerActiveSpoller.querySelector('[data-spoller-title]'), false)
                    }
                    }
                    spollersAnim(footerSpollerTitle)
                }
            }
            e.preventDefault()
        }
        
        // ----------------------------------------------------------------------------------------------------------------------------------

        if(targetElement.closest('.list-filter__more')){
            const listFilterMore = targetElement.closest('.list-filter__more--body');
            const detailsItem = targetElement.closest('.item-filter')
            if(!listFilterMore.closest('.open-more')){
                listFilterMore.classList.add('open-more')
            } else if (detailsItem){
                listFilterMore.classList.remove('open-more')
                detailsItem.removeAttribute('open')
            }
        }

        // if(targetElement.closest('summary')){
        //     const detailsItem = targetElement.closest('details')
        //     detailsItem.classList.toggle('details-open')
        // }

        // ----------------------------------------------------------------------------------------------------------------------------------
        if(isTouchScreen){
            if(targetElement.closest('.languages')){
                const languages = targetElement.closest('.languages');
                languages.classList.toggle('--active');
            } else {
                document.querySelector('.languages').classList.remove('--active');
            }
            if (targetElement.closest('.items-catalog-header__button')) {
				const targetItem = targetElement.closest('.items-catalog-header__item')
				const targetActiveItem = document.querySelector('.items-catalog-header__item.--active')
				targetItem.classList.toggle('--active')

				if (targetItem !== targetActiveItem) {
					targetActiveItem.classList.remove('--active')
				}
			}
        }
        // ----------------------------------------------------------------------------------------------------------------------------------
        if (targetElement.closest('.icon-menu')) {
			document.documentElement.classList.toggle('menu-open')
		}
        // ----------------------------------------------------------------------------------------------------------------------------------
        if(targetElement.closest('.contacts-header')){
            if(targetTag !== "A"){
                const contactsHeader = targetElement.closest('.contacts-header');
                contactsHeader.classList.toggle('--active')
            } else {
                document.querySelector('.contacts-header').classList.remove('--active');
            }
        }
        // ----------------------------------------------------------------------------------------------------------------------------------
        if (targetElement.closest('.catalog-header__button')) {
			const itemsCatalogMenu = document.querySelector('.items-catalog-header');
			document.documentElement.style.setProperty("--menu-catalog-top", `${itemsCatalogMenu.getBoundingClientRect().top + 20}px`)
			document.documentElement.classList.toggle('catalog-open')
		} else if (!targetElement.closest('.items-catalog-header__wrapper')) {
			document.documentElement.classList.remove('catalog-open')
		}
        // ----------------------------------------------------------------------------------------------------------------------------------
        if (targetElement.closest('.actions__item._icon-basket')) {
			document.documentElement.classList.toggle('basket-menu-open')
		} else if (!targetElement.closest('.basket-menu')) {
			document.documentElement.classList.remove('basket-menu-open')
		}
        // ----------------------------------------------------------------------------------------------------------------------------------
        if (targetElement.closest('.basket-menu__close._icon-cross')) {
			document.documentElement.classList.remove('basket-menu-open')
		} 
        // ----------------------------------------------------------------------------------------------------------------------------------
        if(targetElement.closest('.search-header__button-mobile')){
            document.documentElement.classList.toggle('search-open')
		} else if (!targetElement.closest('.search-header')) {
			document.documentElement.classList.remove('search-open')
		}
        // ----------------------------------------------------------------------------------------------------------------------------------
        if (targetElement.closest('.counter-item-basket-menu__minuse')) {
			const currentInput = targetElement.closest('.counter-item-basket-menu__minuse').nextElementSibling
			currentInput.value = currentInput.value - 1 > 0 ? currentInput.value - 1 : 1
			e.preventDefault()
		} else if (targetElement.closest('.counter-item-basket-menu__pluse')) {
			const currentInput = targetElement.closest('.counter-item-basket-menu__pluse').previousElementSibling
			currentInput.value = ++currentInput.value
			e.preventDefault()
		}
        // -------------------------------------------------------------------------------------------------
        if(targetElement.closest('[data-show-more-button]')){
            const showMore = targetElement.closest('[data-show-more]');
            const showMoreHide = showMore.querySelector('[data-show-more-hide]');
            const showMoreHeight = +showMore.dataset.showMore || 280; 
            showMore.classList.toggle('hide');
            showMoreHide.style.height = showMore.classList.contains('hide') ? `${showMoreHeight}px` : ``
		}
        // -------------------------------------------------------------------------------------------------
        if(targetElement.closest('.fabrics-actions-product__button-more')){
            const parentBody = document.querySelector('.fabrics-actions-product__body-more');
            parentBody.classList.toggle('more');
        }
        // -------------------------------------------------------------------------------------------------
        
        if(targetElement.closest('[data-open-replay-button]')){
            const parentElement = targetElement.closest('[data-parent-element]');
            const openReplay = parentElement.querySelector('[data-open-replay]');
            const openComment = parentElement.querySelector('[data-open-comments]')
            openReplay.classList.toggle('element--open');
            if(openComment.closest('.element--open')){
                openComment.classList.remove('element--open');
            }
        }

        // -------------------------------------------------------------------------------------------------
        
        if(targetElement.closest('[data-open-comments-button]')){
            const parentElement = targetElement.closest('[data-parent-element]');
            const openReplay = parentElement.querySelector('[data-open-replay]');
            const openComment = parentElement.querySelector('[data-open-comments]');
            openComment.classList.toggle('element--open');
            if(openReplay.closest('.element--open')){
                openReplay.classList.remove('element--open');
            }
        }

        // -------------------------------------------------------------------------------------------------

        if(document.querySelector('.element--open')){
            const elementOpen = document.querySelector('.element--open');
            if(!targetElement.closest('[data-parent-element]')){
                elementOpen.classList.remove('element--open');
            }
        }
        
        // -------------------------------------------------------------------------------------------------

        if(targetElement.closest('.reviews-content__more')){
            const buttonMore = targetElement.closest('.reviews-content__more');
            const moreItems = document.querySelector('.reviews-content__more-items');
            moreItems.classList.toggle('more');
            buttonMore.classList.toggle('more');
        }
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================


    let spoilersInit = (footerSpoller, isOpen) =>{
        // footerSpollers.forEach(footerSpoller => {
            const footerSpollerTitle = footerSpoller.querySelector('summary')
            footerSpoller.classList.toggle('_init', !isOpen);
            isOpen ? footerSpollerTitle.setAttribute("tabindex", "-1") : footerSpollerTitle.removeAttribute("tabindex")
            footerSpoller.open = isOpen;
        // });
    }

    document.addEventListener("click", documentActions);

    let spollersAnim = (footerSpollerTitle, action) => {
        const footerSpoller = footerSpollerTitle.closest('[data-spoller]')
        const footerSpollerBody = footerSpollerTitle.nextElementSibling
        let spollersAnimClose = () => {
            if (!footerSpollerTitle.classList.contains('_slide')) {
                footerSpollerTitle.classList.add('_slide')
				footerSpollerTitle.classList.remove('_open')
                const footerSpollerBodyHeight = footerSpollerBody.offsetHeight
                footerSpollerBody.style.height = `${footerSpollerBodyHeight}px`
                footerSpollerBody.style.overflow = "hidden"
                footerSpollerBody.style.transitionDuration = "0.8s"
                footerSpollerBody.style.paddingTop = "0"
                footerSpollerBody.style.paddingBottom = "0"
                footerSpollerBody.style.paddingLeft = "0"
                footerSpollerBody.style.paddingRight = "0"
                footerSpollerBody.offsetHeight
                footerSpollerBody.style.height = `0px`
                setTimeout(() => {
                    footerSpoller.open = false
                    footerSpollerBody.style.removeProperty('height')
                    footerSpollerBody.style.removeProperty('overflow')
                    footerSpollerBody.style.removeProperty('transition-duration')

                    footerSpollerBody.style.removeProperty('padding-top')
					footerSpollerBody.style.removeProperty('padding-bottom')
					footerSpollerBody.style.removeProperty('padding-left')
					footerSpollerBody.style.removeProperty('padding-right')

                    footerSpollerTitle.classList.remove('_slide')
                }, 800)
            }
        }
        let spollersAnimOpen = () => {
            if (!footerSpollerTitle.classList.contains('_slide')) {
                footerSpollerTitle.classList.add('_slide')
				footerSpollerTitle.classList.add('_open')
                footerSpoller.open = true
                const footerSpollerBodyHeight = footerSpollerBody.offsetHeight
                footerSpollerBody.style.height = "0"
                footerSpollerBody.style.overflow = "hidden"
                footerSpollerBody.style.paddingTop = "0"
                footerSpollerBody.style.paddingBottom = "0"
                footerSpollerBody.style.paddingLeft = "0"
                footerSpollerBody.style.paddingRight = "0"
                footerSpollerBody.style.transitionDuration = "0.8s"
                footerSpollerBody.offsetHeight
                footerSpollerBody.style.height = `${footerSpollerBodyHeight}px`
                footerSpollerBody.style.removeProperty('padding-top')
                footerSpollerBody.style.removeProperty('padding-bottom')
                footerSpollerBody.style.removeProperty('margin-top')
                footerSpollerBody.style.removeProperty('margin-bottom')
                setTimeout(() => {
                    footerSpollerBody.style.removeProperty('height')
                    footerSpollerBody.style.removeProperty('overflow')
                    footerSpollerBody.style.removeProperty('transition-duration')
                    footerSpollerTitle.classList.remove('_slide')
                }, 800)
            }
        }

        if (action !== undefined) {
            action ? spollersAnimOpen() : spollersAnimClose()
        }
        footerSpoller.open ? spollersAnimClose() : spollersAnimOpen()
    }

    // ---------- Input ----------
    const maskPhone = document.querySelector('.footer-info-product__phone');
    if(maskPhone){
        Inputmask({
            "mask": "+38099-999-99-99",
            "clearIncomplete": true
        }).mask(maskPhone);
    }


    const footerSpollers = document.querySelectorAll('[data-spoller]');
    if(footerSpollers.length){
        footerSpollers.forEach(footerSpoller => {
            const maxWidth = footerSpoller.dataset.spoller || window.innerWidth;
            let maxWidthEm
            if (maxWidth % 2 == 0){
                maxWidthEm = maxWidth;
            } else {
                maxWidthEm = maxWidth + 1;
            }
            const matchMedia = window.matchMedia(`(max-width: ${maxWidthEm / 16}em)`)
            spoilersInit(footerSpoller, !matchMedia.matches);
            matchMedia.addEventListener("change", () => {
                spoilersInit(footerSpoller, !matchMedia.matches);
            }) 
        });
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================

    // Move Header Logo ------------------------------------------------------------------------------
    const header = document.querySelector('.header');
    const topHeader = document.querySelector('.top-header');
    const topHeaderContainer = document.querySelector('.top-header__container');
    const actionsTopHeader = document.querySelector('.actions-top-header');
    const bottomHeader = document.querySelector('.bottom-header');
    const bottomHeaderContainer = document.querySelector('.bottom-header__container');
    const bottomHeaderBody = document.querySelector('.bottom-header__body');
    const catalogHeader = document.querySelector('.catalog-header');
    const searchHeader = document.querySelector('.search-header');
    const contactsHeader = document.querySelector('.contacts-header');
    const centerHeaderActions = document.querySelector('.center-header__actions');
    const centerHeader = document.querySelector('.center-header');
    const centerHeaderContainer = document.querySelector('.center-header__container');

    if (header && bottomHeader && topHeader){
        const matchMedia = window.matchMedia(`(max-width: ${990.98 / 16}em)`)
        moveHeaderElements()
        matchMedia.addEventListener('change', () =>{
            moveHeaderElements()
        })

        function moveHeaderElements() {
            if (matchMedia.matches){
                topHeaderContainer.insertAdjacentElement("beforeend", bottomHeaderBody);
                topHeaderContainer.insertAdjacentElement("beforeend", actionsTopHeader);

                bottomHeaderContainer.insertAdjacentElement("beforeend", catalogHeader)
                bottomHeaderContainer.insertAdjacentElement("beforeend", searchHeader)
                bottomHeaderContainer.insertAdjacentElement("beforeend", centerHeaderActions)
            } else {
                bottomHeaderContainer.insertAdjacentElement("beforeend", bottomHeaderBody)

                centerHeaderContainer.insertAdjacentElement("beforeend", catalogHeader);
                centerHeaderContainer.insertAdjacentElement("beforeend", searchHeader);
                centerHeaderContainer.insertAdjacentElement("beforeend", contactsHeader);
                centerHeaderContainer.insertAdjacentElement("beforeend", centerHeaderActions);
            }
        }
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================

    // Move Footer Logo ------------------------------------------------------------------------------
    const footerLogo = document.querySelector('.footer-socials__logo')
    const footerContainer = document.querySelector('.footer__container')
    const footerSocial = document.querySelector('.footer-socials')

    if (footerLogo) {
        const matchMedia = window.matchMedia(`(max-width: ${767.98 / 16}em)`)
        moveFooterElements()
        matchMedia.addEventListener('change', () => {
            moveFooterElements()
        })

        function moveFooterElements() {
            matchMedia.matches ? footerContainer.insertAdjacentElement("beforeend", footerSocial) : footerContainer.insertAdjacentElement("afterbegin", footerSocial)
            matchMedia.matches ? footerContainer.insertAdjacentElement("afterbegin", footerLogo) : footerSocial.insertAdjacentElement("afterbegin", footerLogo)
        }
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const blockArrows = document.querySelectorAll('.navigation-header-section--salle');
	if (blockArrows.length) {
		const matchMedia = window.matchMedia(`(max-width: ${767.98 / 16}em)`)

		moveblockArrowsElements()
		matchMedia.addEventListener('change', () => {
			moveblockArrowsElements()
		})
		function moveblockArrowsElements() {
        const oldPlace = document.querySelector('.salle__header');
			blockArrows.forEach(blockArrow => {
				const newPlace = blockArrow.closest('[class*="__container"]')
				matchMedia.matches ? newPlace.insertAdjacentElement("beforeend", blockArrow) : oldPlace.insertAdjacentElement("beforeend", blockArrow)
			});
		}
	}

    const showMores = document.querySelectorAll('[data-show-more]');
    if(showMores.length){
        showMores.forEach(showMore => {
            const showMoreHide = showMore.querySelector('[data-show-more-hide]');
            const showMoreHeight = +showMore.dataset.showMore || 280;
            if(showMoreHide.offsetHeight > showMoreHeight){
                showMore.classList.add('hide');
                showMore.classList.add('active');
                showMoreHide.style.height = `${showMoreHeight}px`;
            }
        });
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const swiperIntro = new Swiper('.swiper-intro', {

        // Optional parameters----------------------------------------------------------
        loop: true,

        // If we need pagination ----------------------------------------------------------
        pagination: {
            el: '.swiper-intro__pagination',
            clickable: true,
        },

        // Navigation arrows ----------------------------------------------------------
        navigation: {
            nextEl: '.swiper-intro__button-next',
            prevEl: '.swiper-intro__button-prev',
        }
    });

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const swiperSalle = new Swiper('.swiper-salle', {

        // Optional parameters ----------------------------------------------------------
        loop: true,
        slidesPerView: 3,
		spaceBetween: 30,

        // Navigation arrows ----------------------------------------------------------
        navigation: {
            nextEl: '.arrow--right--salle',
            prevEl: '.arrow--left--salle',
        },

        // Breakpoints ----------------------------------------------------------
        breakpoints: {
			// when window width is >= 320px
			320: {
				slidesPerView: 1.2,
				spaceBetween: 10
			},
			// when window width is >= 480px
			470: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			// when window width is >= 640px
			800: {
				slidesPerView: 3,
				spaceBetween: 30
			}
		}
    });

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const swiperReviews = new Swiper('.slider-reviews__swiper', {

        // Optional parameters ----------------------------------------------------------
        slidesPerView: "auto",
        spaceBetween: 30,

        scrollbar: {
			el: ".slider-reviews__scrollbar",
			dragClass: "reviews__drag-scroll",
			hide: false,
			dragSize: 50,
			draggable: true,
		},
        // Breakpoints ----------------------------------------------------------
        breakpoints: {
            // when window width is >= 320px
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            },
            450: {
                slidesPerView: 1.3,
                spaceBetween: 15
            },
            // when window width is >= 480px
            767: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            // when window width is >= 640px
            1150: {
                slidesPerView: "auto",
                spaceBetween: 30,
            }
        }
    });

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const swiperNewNews = new Swiper('.new-news__swiper', {

        // Optional parameters ----------------------------------------------------------
        loop: true,
        slidesPerView: 3,
        spaceBetween: 30,

        // Navigation arrows ----------------------------------------------------------
        navigation: {
            nextEl: '.arrow--next--new-news',
            prevEl: '.arrow--prev--new-news',
        },

        // Breakpoints ----------------------------------------------------------
        breakpoints: {
            // when window width is >= 320px
            320: {
                slidesPerView: 1.15,
                spaceBetween: 10
            },
            // when window width is >= 480px
            650: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            // when window width is >= 640px
            990: {
                slidesPerView: 3,
                spaceBetween: 30
            }
        }
    });

// ================================================================================================
// ===============================================================================================
// ================================================================================================

    const priceRange = document.querySelector('.price-filter__range');
    if(priceRange){
        const priceRangeInputs = document.querySelectorAll('.actions-price-filter__input');
        const formatForSlider = {
            from: function (formattedValue) {
                return Number(formattedValue);
            },
            to: function (numericValue) {
                return Math.round(numericValue);
            }
        };
        noUiSlider.create(priceRange, {
            start: [20, 80],
            connect: true,
            format: formatForSlider,
            range: {
                'min': 0,
                'max': 100
            }
        });
        priceRange.noUiSlider.on('update', function (values, handle) {
            priceRangeInputs[handle].value = values[handle];
        });
        priceRangeInputs.forEach((priceRangeInput, index) => {
            priceRangeInput.addEventListener('change', function () {
                priceRange.noUiSlider.setHandle(index, this.value);
            })
        });
    }

// ================================================================================================
// ================================================================================================
// ================================================================================================

    const swiperSubWare = new Swiper('.photos-product__sub-swiper', {
        // Optional parameters ----------------------------------------------------------
        slidesPerView: 5,
        spaceBetween: 20,
        loop: true,
		freeMode: true,
		watchSlidesProgress: true,
    });

    
    const swiperMainWare = new Swiper('.photos-product__main-swiper', {

        // Optional parameters ----------------------------------------------------------
        loop: true,
        slidesPerView: 1,
        spaceBetween: 30,
        thumbs: {
            swiper: swiperSubWare,
        },

        // Navigation arrows ----------------------------------------------------------
        navigation: {
            nextEl: '.photos-product__main-arrow--next',
            prevEl: '.photos-product__main-arrow--prev',
        },
    });

    // ================================================================================================
// ================================================================================================
// ================================================================================================

}

// ================================================================================================
// ==============================================================================================================================
// ===============================================================================================================================================
// ==============================================================================================================================
// ================================================================================================
